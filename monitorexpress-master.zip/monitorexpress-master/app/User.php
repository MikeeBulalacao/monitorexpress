<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'firstname', 'lastname', 'email', 'password', 'api_token',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    public function scopePassenger($query)
    {
        $firstname = request('firstname');
        $lastname = request('lastname');
        $email = request('email');

        /*$emaildata = User::select('users.email')->where('users.email', '=', $email)->get()->count();
        if($emaildata > 0){
            return[
                'status' => 400,
                'message' => 'duplicate email, try another',
                'firstname' => '',
                'lastname' => '',
                'email' => '',
            ];

        }*/

        $passenger = new $this;
        $passenger->firstname = request('firstname');
        $passenger->lastname = request('lastname');
        $passenger->email = request('email');
        $passenger->password = bcrypt(request('password'));
        $passenger->api_token = uniqid();

        $passenger->createCustomColumn = json_encode(request()->all()); 

        if($passenger->save()){
            return[
                'status' => 200,
                'message' => 'Successful Registration',
                'firstname' => $firstname,
                'lastname' => $lastname,
                'email' => $email
            ];
        } else{
            return[
                'status' => 400,
                'message' => 'registration failed!',
                'firstname' => '',
                'lastname' => '',
                'email' => '',
            ];
        }
    }

    public function scopePassengerlogin($query)
    {
        $passengerEmail = request('email');
        $passengerPassword = request('password');
        $passenger = User::select(
                            'users.firstname',
                            'users.lastname',
                            'users.email',
                            'users.password')
                        ->where('users.email', '=', $passengerEmail)
                        ->get();

        if($passenger->count() > 0){
            foreach ($passenger as $key => $value) {
                $firstname = $value['firstname'];
                $lastname = $value['lastname'];
                $password = $value['password'];
                $email = $value['email'];

                if(($email == $passengerEmail) && (password_verify($passengerPassword, $password))){
                    return[
                        'status' => 200,
                        'message' => 'Successful Login',
                        'firstname' => $firstname,
                        'lastname' => $lastname,
                        'email' => $email
                    ];
                } else{
                    return[
                        'status' => 400,
                        'message' => 'login failed!',
                        'firstname' => '',
                        'lastname' => '',
                        'email' => ''
                    ];
                }
            }
        } else{
            return[
                'status' => 400,
                'message' => 'The email you have entered does not match any account',
                'firstname' => '',
                'lastname' => '',
                'email' => ''
            ];
        }
    }
}
